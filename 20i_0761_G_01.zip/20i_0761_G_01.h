//Asadullah Nawaz
//20I-0761
//CS-G
//Assignment-1


#ifndef APRIORI_H
#define APRIORI_H

#include<iostream>
#include<fstream>
using namespace std;


char* removeChar(char*, int);
bool compare(char*, char*);

template <class T>
class ItemNode {

public:

	T data;
	int frequency;
	ItemNode* next;

	ItemNode() {

		frequency = 0;

	}

	ItemNode(const ItemNode<T>& obj) {

		data = new char[100];

		int i = 0;
		for (; obj.data[i] != '\0'; i++)
			data[i] = obj.data[i];

		data[i] = '\0';

		frequency = obj.frequency;
		next = obj.next;

	}

	void operator=(const ItemNode<T>& obj) {

		data = new char[100];
		int i = 0;
		for (; obj.data[i] != '\0'; i++)
			data[i] = obj.data[i];

		data[i] = '\0';

		frequency = obj.frequency;
		next = obj.next;

	}

};

template <class T>
class TransactionNode {

public:
	ItemNode<T>* headRow;
	TransactionNode* nextRow;
	int no_items;

	TransactionNode() {

		headRow = NULL;
		no_items = 0;
	}

	TransactionNode(const TransactionNode<T>& obj) {

		no_items = obj.no_items;
		headRow = new ItemNode<T>;
		*headRow = *obj.headRow;
		nextRow = new ItemNode<T>;
		*nextRow = *obj.headRow;
	}

	void operator=(const TransactionNode<T>& obj) {

		no_items = obj.no_items;
		headRow = new ItemNode<T>;
		*headRow = *obj.headRow;
		nextRow = new ItemNode<T>;
		*nextRow = *obj.headRow;
	}

	ItemNode<T>* insertItem(int index, T item, int frequency = 0) {

		if (index < 0)
			return NULL;

		int currentIndex = 1;
		ItemNode<T>* currentNode = headRow;

		while (currentNode && currentIndex < index) {

			currentNode = currentNode->next;
			currentIndex++;
		}

		if (index > 0 && currentNode == NULL)
			return NULL;

		ItemNode<T>* newNode = new ItemNode<T>;
		newNode->data = item;
		newNode->frequency = frequency;
		no_items++;

		if (index == 0) {

			newNode->next = headRow;
			headRow = newNode;

		}

		else {

			newNode->next = currentNode->next;
			currentNode->next = newNode;

		}

		return newNode;

	}


	ItemNode<T>* insertItemPairs(int index, T item1, T item2) {

		if (index < 0)
			return NULL;

		int currentIndex = 1;
		ItemNode<T>* currentNode = headRow;

		while (currentNode && currentIndex < index) {

			currentNode = currentNode->next;
			currentIndex++;
		}

		if (index > 0 && currentNode == NULL)
			return NULL;

		ItemNode<T>* newNode = new ItemNode<T>[2];
		newNode->data = new char* [2];
		newNode->data[0] = *item1;
		newNode->data[1] = *item2;

		no_items++;

		if (index == 0) {

			newNode->next = headRow;
			headRow = newNode;

		}

		else {

			newNode->next = currentNode->next;
			currentNode->next = newNode;

		}

		return newNode;

	}

	ItemNode<T>* insertItemTriplets(int index, T item1, T item2, T item3) {

		if (index < 0)
			return NULL;

		int currentIndex = 1;
		ItemNode<T>* currentNode = headRow;

		while (currentNode && currentIndex < index) {

			currentNode = currentNode->next;
			currentIndex++;
		}

		if (index > 0 && currentNode == NULL)
			return NULL;

		ItemNode<T>* newNode = new ItemNode<T>[2];
		newNode->data = new char* [3];
		newNode->data[0] = *item1;
		newNode->data[1] = *item2;
		newNode->data[2] = *item3;

		no_items++;

		if (index == 0) {

			newNode->next = headRow;
			headRow = newNode;

		}

		else {

			newNode->next = currentNode->next;
			currentNode->next = newNode;

		}

		return newNode;

	}

	void printRow(int a = 0) {

		ItemNode<T>* temp = headRow;

		while (temp != NULL) {

			if (a == 0)
				cout << temp->data << " ";
			else if (a == 1)
				cout << temp->data[0] << " " << temp->data[1] << " " << endl;
			else if (a == 2)
				cout << temp->data[0] << " " << temp->data[1] << " " << temp->data[2] << " " << temp->frequency << endl;

			temp = temp->next;

		}

	}


	int deleteItem(T item) {

		ItemNode<T>* currentNode = headRow;
		ItemNode<T>* prevNode = NULL;
		int currentIndex = 1;

		while (currentNode && currentNode->data != item) {

			prevNode = currentNode;
			currentNode = currentNode->next;
			currentIndex++;

		}

		if (currentNode != NULL) {

			if (prevNode == NULL) {

				headRow = headRow->next;
				//delete currentNode;


			}

			else {

				prevNode->next = currentNode->next;
				//delete currentNode;

			}
			no_items--;
			return currentIndex;

		}

		return 0;

	}

	int deleteItemByAddress(ItemNode<T>* deleteNode) {

		ItemNode<T>* currentNode = headRow;
		ItemNode<T>* prevNode = NULL;
		int currentIndex = 1;

		while (currentNode && currentNode != deleteNode) {

			prevNode = currentNode;
			currentNode = currentNode->next;
			currentIndex++;

		}

		if (currentNode != NULL) {

			if (prevNode == NULL) {

				headRow = headRow->next;
				//delete currentNode;


			}

			else {

				prevNode->next = currentNode->next;
				//delete currentNode;

			}
			no_items--;
			return currentIndex;

		}

		return 0;

	}


	void empty() {

		ItemNode<T>* current = headRow;
		ItemNode<T>* nextNode;

		while (current) {

			nextNode = current->next;
			delete current;
			current = nextNode;
		}
		no_items = 0;
		headRow = NULL;
	}

	void sortList() {

		T temp1;
		int temp2;
		ItemNode<T>* current;

		for (int i = 0; i < no_items; i++) {

			current = headRow;

			while (current->next) {

				if (current->frequency < (current->next)->frequency) {

					temp1 = current->data;
					current->data = (current->next)->data;
					(current->next)->data = temp1;

					temp2 = current->frequency;
					current->frequency = (current->next)->frequency;
					(current->next)->frequency = temp2;

				}
				current = current->next;
			}

		}

	}

};

template <class T>
class TransactionLL {

	TransactionNode<T>* head;
	int numTransactions;
	float support;
	float supportThreshold;

public:

	TransactionLL() {

		head = NULL;
		numTransactions = 0;
		support = 0;
		supportThreshold = 0;

	}

	void setNumTransactions(int n) {

		numTransactions = n;
	}

	void setSupport(float s) {

		support = s;
	}

	void setSupportThreshold() {

		supportThreshold = support * numTransactions;
	}

	int getNumTransactions() {

		return numTransactions;
	}

	float getSupportThreshold() {

		return supportThreshold;
	}

	TransactionNode<T>* getHead() {

		return head;
	}

	TransactionNode<T>* insertTransaction(int index, T* Transaction, int length) {

		if (index < 0)
			return NULL;

		int currentIndex = 1;
		TransactionNode<T>* currentNode = head;

		while (currentNode && currentIndex < index) {

			currentNode = currentNode->nextRow;
			currentIndex++;

		}

		if (index > 0 && currentNode == NULL)
			return NULL;

		TransactionNode<T>* newNode = new TransactionNode<T>;

		for (int i = 0; i < length; i++) {

			newNode->insertItem(i, Transaction[i]);

		}

		if (index == 0) {

			newNode->nextRow = head;
			head = newNode;

		}

		else {

			newNode->nextRow = currentNode->nextRow;
			currentNode->nextRow = newNode;

		}



		return newNode;
	}

	void insertTransactionItem(int indexRow, int indexItem, T item) {

		if (indexRow < 0)
			return;

		int currentIndex = 0;
		TransactionNode<T>* currentNode = head;

		while (currentNode && currentIndex < indexRow) {

			currentNode = currentNode->nextRow;
			currentIndex++;

		}


		currentNode->insertItem(indexItem, item);
	}


	void printTransactions() {

		TransactionNode<T>* temp = head;

		while (temp != NULL) {

			temp->printRow();
			cout << endl;

			temp = temp->nextRow;

		}

	}


	void printFrequency() {

		TransactionNode<T>* row = head;
		ItemNode<T>* item;


		while (row) {

			item = row->headRow;

			while (item) {


				cout << item->data << "\t" << item->frequency << "\t";

				item = item->next;

			}

			cout << endl;
			row = row->nextRow;
		}

	}


	int deleteTransactionItem(int index, T item) {

		if (index < 0)
			return 0;

		int currentIndex = 1;

		TransactionNode<T>* currentNode = head;

		while (currentNode && currentIndex < index) {

			currentNode = currentNode->nextRow;
			currentIndex++;
		}

		if (index > 0 && currentNode == NULL)
			return 0;

		else
			return currentNode->deleteItem(item);

	}

	void emptyTransactions() {

		TransactionNode<T>* current = head;
		TransactionNode<T>* nextNode;

		while (current) {

			nextNode = current->nextRow;
			current->empty();
			current = nextNode;

		}

		head = NULL;
	}

	~TransactionLL() {

		emptyTransactions();

	}

};

TransactionLL<char*> Apriori;

//Step-1
void readInputFile(char* inputFilePath) {

	Apriori.emptyTransactions();

	char* temp1;
	char* temp2;
	int size;
	float n;
	ifstream file;
	file.open(inputFilePath);

	file >> n;
	Apriori.setSupport(n);
	file >> n;
	Apriori.setNumTransactions(n);

	Apriori.setSupportThreshold();

	temp1 = new char[100];
	file.getline(temp1, 100, '\n');

	int k, l;
	for (int i = 0; !file.eof(); i++) {

		temp1 = new char[100];
		file.getline(temp1, 100, '\n');

		temp2 = new char[100];
		Apriori.insertTransaction(i, NULL, 0);

		k = 0;
		l = 0;
		for (int j = 0; temp1[j] != '\0' && temp1[j] != '\n'; j++) {

			if (temp1[j] != ',') {
				temp2[k] = temp1[j];
				k++;
			}

			else {
				temp2[k] = '\0';
				Apriori.insertTransactionItem(i, l, temp2);
				temp2 = new char[100];
				k = 0;
				l++;

			}


		}

		temp2[k] = '\0';
		Apriori.insertTransactionItem(i, l, temp2);
		delete temp1;

	}

	file.close();


}

//Step-2(a)
void removePunctuationMarks() {

	TransactionNode<char*>* row = Apriori.getHead();
	ItemNode<char*>* item;

	while (row) {

		item = row->headRow;

		while (item) {


			for (int i = 0; item->data[i] != '\0'; i++) {

				if ((item->data[i] >= 65 && item->data[i] <= 90) || (item->data[i] >= 97 && item->data[i] <= 122) || (item->data[i] == ' '))
					continue;

				item->data = removeChar(item->data, i);

			}

			item = item->next;

		}

		row = row->nextRow;
	}


}

//Step-2(b)
void convertUpperToLowerCase() {

	TransactionNode<char*>* row = Apriori.getHead();
	ItemNode<char*>* item;


	while (row) {

		item = row->headRow;

		while (item) {


			for (int i = 0; item->data[i] != '\0'; i++) {

				if ((item->data[i] >= 65 && item->data[i] <= 90))
					item->data[i] += 32;

			}

			item = item->next;

		}

		row = row->nextRow;
	}

}

//Writing File
void writingTransactionLLToFile(char* outputFilePath) {

	TransactionNode<char*>* row = Apriori.getHead();
	ItemNode<char*>* item;

	ofstream file;
	file.open(outputFilePath);

	while (row) {

		item = row->headRow;
		while (item) {

			file << item->data;

			if (item->next != NULL)
				file << ",";

			item = item->next;

		}

		if (row->nextRow != NULL)
			file << endl;

		row = row->nextRow;
	}


	file.close();

}

//Step-3
//Calculating Indiviadual Frequencies of Each Item
void generateFrequency() {

	TransactionNode<char*>* row = Apriori.getHead();
	ItemNode<char*>* item;

	TransactionNode<char*>* row2;
	ItemNode<char*>* item2;


	while (row) {

		item = row->headRow;

		while (item) {

			row2 = Apriori.getHead();

			while (row2) {


				item2 = row2->headRow;

				while (item2) {

					if (compare(item->data, item2->data))
						item->frequency++;

					item2 = item2->next;
				}

				row2 = row2->nextRow;

			}

			item = item->next;

		}

		row = row->nextRow;
	}



}

//Step-3
void generateFirstItemSet(char* LL_frequency) {

	generateFrequency();

	TransactionNode<char*>* row = Apriori.getHead();
	ItemNode<char*>* item;
	TransactionNode<char*>* row2;
	ItemNode<char*>* item2;
	ItemNode<char*>* temp;
	int transaction_no = 1;

	//Deleting Items with Frequency Less Than Support Threshold
	while (row) {

		item = row->headRow;



		while (item) {


			if (item->frequency < Apriori.getSupportThreshold())
				Apriori.deleteTransactionItem(transaction_no, item->data);

			item = item->next;

		}

		transaction_no++;
		row = row->nextRow;
	}



	//Forming First ItemSet
	TransactionNode<char*> SingleList;
	ItemNode<char*>* current;

	int n = 0;
	bool check;

	

	row = Apriori.getHead();
	while (row) {

		item = row->headRow;

		while (item) {

			check = 1;

			current = SingleList.headRow;
			while (current) {

				if (compare(current->data, item->data))
					check = 0;

				current = current->next;
			}

			if (check == 1)
				SingleList.insertItem(n++, item->data, item->frequency);


			item = item->next;

		}

		row = row->nextRow;
	}


	//Sorting FirstItemSet
	SingleList.sortList();

	//Writing Frequencies to File

	ofstream file;
	file.open(LL_frequency);

	current = SingleList.headRow;
	while (current) {

		file << current->data << "(" << current->frequency << ")";
		current = current->next;

		if (current)
			file << endl;
	}

	file.close();


}

//Step-4
void generateSecondItemSet(char* frequency_outputfile) {

	generateFrequency();

	TransactionNode<char*>* row = Apriori.getHead();
	ItemNode<char*>* item;

	TransactionNode<char*>* row2;
	ItemNode<char*>* item2;

	TransactionNode<char**> PairsList;
	ItemNode<char**>* current;
	int n = 0;
	bool check;

	//Forming Second ItemSet
	while (row) {

		item = row->headRow;

		while (item) {

			row2 = Apriori.getHead();

			while (row2) {


				item2 = row2->headRow;


				while (item2) {

					current = PairsList.headRow;
					check = 1;
					while (current) {

						if (compare(current->data[0], item->data) && compare(current->data[1], item2->data))
							check = 0;

						else if (compare(current->data[1], item->data) && compare(current->data[0], item2->data))
							check = 0;

						current = current->next;
					}

					if (check == 1 && !compare(item->data, item2->data)) {


						if (item->frequency >= item2->frequency)
							PairsList.insertItemPairs(n++, &item->data, &item2->data);

						else
							PairsList.insertItemPairs(n++, &item2->data, &item->data);
					}


					item2 = item2->next;
				}

				row2 = row2->nextRow;

			}

			item = item->next;

		}

		row = row->nextRow;
	}

	//Calculating Frequencies of SecondItemSet
	current = PairsList.headRow;

	int count;
	while (current) {
		row = Apriori.getHead();
		while (row) {

			item = row->headRow;
			count = 0;

			while (item) {

				if (compare(item->data, current->data[0]) || compare(item->data, current->data[1]))
					count++;

				item = item->next;
			}

			if (count == 2)
				current->frequency++;

			row = row->nextRow;
		}
		current = current->next;
	}

	//Deleting/Pruning pairs with Frequency less than Support Threshold 	
	current = PairsList.headRow;
	while (current) {


		if (current->frequency < Apriori.getSupportThreshold()) {
			PairsList.deleteItemByAddress(current);
		}

		current = current->next;
	}


	//Sorting SecondItemSet
	PairsList.sortList();

	//Writing To File
	ofstream file;
	file.open(frequency_outputfile);

	current = PairsList.headRow;
	while (current) {

		file << current->data[0] << "," << current->data[1] << "(" << current->frequency << ")";

		current = current->next;

		if (current)
			file << endl;
	}

	file.close();

}

//Step-5
void generateThirdItemSet(char* frequency_outputfile) {

	generateFrequency();

	TransactionNode<char*>* row = Apriori.getHead();
	ItemNode<char*>* item;

	TransactionNode<char*>* row2;
	ItemNode<char*>* item2;

	TransactionNode<char*>* row3;
	ItemNode<char*>* item3;

	TransactionNode<char**> TripletsList;
	ItemNode<char**>* current;
	int n = 0;
	bool check;

	//Forming Third ItemSet
	while (row) {

		item = row->headRow;

		while (item) {

			row2 = Apriori.getHead();

			while (row2) {


				item2 = row2->headRow;


				while (item2) {

					row3 = Apriori.getHead();

					while (row3) {

						item3 = row->headRow;

						while (item3) {

							current = TripletsList.headRow;
							check = 1;
							while (current) {

								if (compare(current->data[0], item->data) && compare(current->data[1], item2->data) && compare(current->data[2], item3->data))
									check = 0;

								else if (compare(current->data[0], item->data) && compare(current->data[2], item2->data) && compare(current->data[1], item3->data))
									check = 0;

								else if (compare(current->data[1], item->data) && compare(current->data[0], item2->data) && compare(current->data[2], item3->data))
									check = 0;

								else if (compare(current->data[1], item->data) && compare(current->data[2], item2->data) && compare(current->data[0], item3->data))
									check = 0;

								else if (compare(current->data[2], item->data) && compare(current->data[1], item2->data) && compare(current->data[0], item3->data))
									check = 0;

								else if (compare(current->data[2], item->data) && compare(current->data[0], item2->data) && compare(current->data[1], item3->data))
									check = 0;

								current = current->next;
							}

							if (check == 1 && !compare(item->data, item2->data) && !compare(item->data, item3->data) && !compare(item2->data, item3->data)) {


								if (item->frequency >= item2->frequency && item->frequency >= item3->frequency && item2->frequency >= item3->frequency)
									TripletsList.insertItemTriplets(n++, &item->data, &item2->data, &item3->data);

								else if (item->frequency >= item2->frequency && item->frequency >= item3->frequency && item3->frequency >= item2->frequency)
									TripletsList.insertItemTriplets(n++, &item->data, &item3->data, &item2->data);

								else if (item2->frequency >= item->frequency && item2->frequency >= item3->frequency && item->frequency >= item3->frequency)
									TripletsList.insertItemTriplets(n++, &item2->data, &item->data, &item3->data);

								else if (item2->frequency >= item->frequency && item2->frequency >= item3->frequency && item3->frequency >= item->frequency)
									TripletsList.insertItemTriplets(n++, &item2->data, &item3->data, &item->data);

								else if (item3->frequency >= item->frequency && item3->frequency >= item2->frequency && item->frequency >= item2->frequency)
									TripletsList.insertItemTriplets(n++, &item3->data, &item->data, &item2->data);

								else if (item3->frequency >= item->frequency && item3->frequency >= item2->frequency && item2->frequency >= item->frequency)
									TripletsList.insertItemTriplets(n++, &item3->data, &item2->data, &item->data);
							}

							item3 = item3->next;
						}
						row3 = row3->nextRow;
					}
					item2 = item2->next;
				}

				row2 = row2->nextRow;

			}

			item = item->next;

		}

		row = row->nextRow;
	}

	//Calculating Frequencies of ThirdItemSet
	current = TripletsList.headRow;

	int count;
	while (current) {
		row = Apriori.getHead();
		while (row) {

			item = row->headRow;
			count = 0;

			while (item) {

				if (compare(item->data, current->data[0]) || compare(item->data, current->data[1]) || compare(item->data, current->data[2]))
					count++;

				item = item->next;
			}

			if (count == 3)
				current->frequency++;

			row = row->nextRow;
		}
		current = current->next;
	}

	//Deleting/Pruning Triplets with Frequency < SupportThreshold	
	current = TripletsList.headRow;
	while (current) {


		if (current->frequency < Apriori.getSupportThreshold()) {
			TripletsList.deleteItemByAddress(current);
		}

		current = current->next;
	}


	//Sorting ThirdItemSet
	TripletsList.sortList();

	//Writing To File
	ofstream file;
	file.open(frequency_outputfile);

	current = TripletsList.headRow;
	while (current) {

		file << current->data[0] << "," << current->data[1] << "," << current->data[2] << "(" << current->frequency << ")";

		current = current->next;

		if (current)
			file << endl;
	}

	file.close();

}

//HELPER FUNCTIONS

char* removeChar(char* str, int index) {

	int i = index;
	int count;
	char temp;
	for (; str[i + 1] != '\0'; i++) {

		temp = str[i];
		str[i] = str[i + 1];
		str[i + 1] = temp;
	}

	str[i] = '\0';


	return str;

}

bool compare(char* s1, char* s2) {

	int l1 = 0, l2 = 0;

	for (int i = 0; s1[i] != '\0'; i++)
		l1++;

	for (int i = 0; s2[i] != '\0'; i++)
		l2++;

	if (l1 != l2)
		return 0;

	for (int i = 0; s1[i] != '\0'; i++)
		if (s1[i] != s2[i])
			return 0;

	return 1;
}

#endif
